/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lugas;

/**
 *
 * @author WS
 */
public class Lugas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
